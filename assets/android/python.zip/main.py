import sys
print(sys.version)
print("Hello Python")

import sys
from pylsp.__main__ import main

sys.argv = ["pylsp", "--ws", "--host", "127.0.0.1", "--port", "2026", "--verbose"]
main()

print("Pylsp Exit")